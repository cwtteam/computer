-- ============================================================
-- CWT Dropship System — Supabase Database Schema
-- วิธีใช้: copy ทั้งหมดนี้ไปวางใน Supabase SQL Editor แล้วกด Run
-- ============================================================

-- Enable realtime for all tables
-- (ทำใน Supabase Dashboard > Table Editor > Enable Realtime)

-- ── 1. INVENTORY ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS inventory (
  id          BIGSERIAL PRIMARY KEY,
  sku         TEXT NOT NULL,
  size        TEXT,
  supplier    TEXT,
  category    TEXT,
  lot_no      TEXT,
  quantity    INTEGER DEFAULT 0,
  condition   TEXT DEFAULT 'ปกติ',
  status      TEXT DEFAULT 'พร้อมขาย',
  cost        NUMERIC(10,2) DEFAULT 0,
  price_w     NUMERIC(10,2) DEFAULT 0,
  price_r     NUMERIC(10,2) DEFAULT 0,
  shipping    NUMERIC(10,2) DEFAULT 0,
  order_id    TEXT,
  batch_id    TEXT,
  recipient   TEXT,
  date_in     DATE,
  date_out    DATE,
  date_return DATE,
  note        TEXT,
  image_url   TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── 2. INBOUND ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS inbound (
  id          BIGSERIAL PRIMARY KEY,
  date_in     DATE,
  sku         TEXT NOT NULL,
  size        TEXT,
  supplier    TEXT,
  category    TEXT,
  lot_no      TEXT,
  boxes       INTEGER DEFAULT 0,
  quantity    INTEGER DEFAULT 0,
  order_id    TEXT,
  batch_id    TEXT,
  condition   TEXT DEFAULT 'ปกติ',
  note        TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── 3. OUTBOUND ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS outbound (
  id            BIGSERIAL PRIMARY KEY,
  date_out      DATE,
  sku           TEXT NOT NULL,
  size          TEXT,
  supplier      TEXT,
  lot_no        TEXT,
  category      TEXT,
  quantity      INTEGER DEFAULT 0,
  order_id      TEXT,
  batch_id      TEXT,
  is_return     BOOLEAN DEFAULT FALSE,
  recipient     TEXT,
  shipping_cost NUMERIC(10,2) DEFAULT 0,
  note          TEXT,
  cost_per      NUMERIC(10,2) DEFAULT 0,
  price_per     NUMERIC(10,2) DEFAULT 0,
  profit_per    NUMERIC(10,2) DEFAULT 0,
  profit_total  NUMERIC(10,2) DEFAULT 0,
  margin_pct    NUMERIC(5,2) DEFAULT 0,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── 4. RETURNS ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS returns (
  id          BIGSERIAL PRIMARY KEY,
  date_return DATE,
  order_id    TEXT,
  supplier    TEXT,
  lot_no      TEXT,
  sku         TEXT,
  size        TEXT,
  quantity    INTEGER DEFAULT 0,
  cause       TEXT,
  condition   TEXT,
  note        TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── 5. CUSTOMERS ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS customers (
  id          BIGSERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  nickname    TEXT,
  phone       TEXT,
  line_id     TEXT,
  address     TEXT,
  province    TEXT,
  postal_code TEXT,
  platform    TEXT DEFAULT 'Sasom',
  lot_no      TEXT,
  status      TEXT DEFAULT 'ปกติ',
  note        TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── 6. SUPPLIERS ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS suppliers (
  id            BIGSERIAL PRIMARY KEY,
  code          TEXT,
  name          TEXT NOT NULL,
  contact       TEXT,
  email         TEXT,
  country       TEXT DEFAULT 'CHINA',
  status        TEXT DEFAULT 'ใช้งาน',
  payment_terms TEXT,
  lead_time_days INTEGER,
  note          TEXT,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── SEED: Suppliers จากไฟล์ Excel ────────────────────────
INSERT INTO suppliers (code, name, contact, email, country, status) VALUES
  ('LB-1', 'LB1',   'กล้าม',  'hiphypebkk@gmail.com',   'CHINA', 'ใช้งาน'),
  ('LB-1', 'LB1.1', 'แว่น',   'hiphypebkk@gmail.com',   'CHINA', 'ใช้งาน'),
  ('LB-2', 'LB2',   'พี่เป้ง', 'pengchenfuli@gmail.com', 'CHINA', 'ใช้งาน'),
  ('LB-3', 'LB3',   'TPO',    'tpogwbhr@hotmail.com',   'CHINA', 'ใช้งาน'),
  ('LB-3', 'LB3.1', 'PH',     'phxhtndyd@hotmail.com',  'CHINA', 'ใช้งาน'),
  ('LB-3', 'LB3.2', 'Vslh',   'vslh66@163.com',         'CHINA', 'ใช้งาน')
ON CONFLICT DO NOTHING;

-- ── SEED: Inventory จากไฟล์ Excel ────────────────────────
INSERT INTO inventory (sku, size, supplier, category, lot_no, quantity, condition, status) VALUES
  ('SUP-SOASHCSCS4PWHKKN', 'One Size', 'LB1', 'ถุงเท้า', 'Lotปี25', 2, 'ปกติ', 'พร้อมขาย'),
  ('SUP-SOASHCSCS4PWHKKN', 'One Size', 'LB1', 'ถุงเท้า', 'Lotปี25', 3, 'ปกติ', 'พร้อมขาย'),
  ('SUP-SOASHCSCS4PWHKKN', 'One Size', 'LB1', 'ถุงเท้า', 'Lotปี25', 4, 'ปกติ', 'พร้อมขาย'),
  ('HQ8708', '9',    'LB1', 'รองเท้า', 'Lot1', 2, 'ปกติ', 'พร้อมขาย'),
  ('HQ8708', '9.5',  'LB1', 'รองเท้า', 'Lot1', 4, 'ปกติ', 'พร้อมขาย'),
  ('HQ8708', '10',   'LB1', 'รองเท้า', 'Lot1', 4, 'ปกติ', 'พร้อมขาย'),
  ('CW2288-111', '8', 'LB1', 'รองเท้า', 'Lot1', 1, 'ปกติ', 'พร้อมขาย'),
  ('DC0774-101', '7.5','LB1','รองเท้า', 'Lot1', 2, 'ปกติ', 'พร้อมขาย'),
  ('B75806', '7',    'LB1', 'รองเท้า', 'Lot2', 2, 'ปกติ', 'พร้อมขาย'),
  ('B75806', '8',    'LB1', 'รองเท้า', 'Lot2', 3, 'ปกติ', 'พร้อมขาย'),
  ('B75807', '5',    'LB1', 'รองเท้า', 'Lot3', 1, 'ปกติ', 'พร้อมขาย'),
  ('B75807', '7',    'LB1', 'รองเท้า', 'Lot3', 1, 'ปกติ', 'พร้อมขาย'),
  ('CW2288-001', '7.5','LB1','รองเท้า','Lot3',27, 'ปกติ', 'พร้อมขาย'),
  ('125HO244360F', 'xs', 'LB1', 'เสื้อ', '', 1, 'ปกติ', 'พร้อมขาย'),
  ('125HO244360F', 's',  'LB1', 'เสื้อ', '', 1, 'ปกติ', 'พร้อมขาย')
ON CONFLICT DO NOTHING;

-- ── SEED: Outbound ────────────────────────────────────────
INSERT INTO outbound (date_out, sku, size, supplier, lot_no, category, quantity, order_id, note) VALUES
  ('2026-01-06','HQ8708','9',   'LB1','Lot1','รองเท้า',3,'SMBB-KJ3xq-1767684094764','Lot1'),
  ('2026-01-06','HQ8708','9.5', 'LB1','Lot1','รองเท้า',5,'SMBB-KJ3xq-1767684094764','Lot1'),
  ('2026-01-06','HQ8708','10',  'LB1','Lot1','รองเท้า',5,'SMBB-KJ3xq-1767684094764','Lot1'),
  ('2026-01-06','CW2288-111','8','LB1','Lot1','รองเท้า',2,'SMBB-KJ3xq-1767684094764','Lot1'),
  ('2026-01-09','HQ8708','8',  'LB1','Lot2','รองเท้า',5,'SMBB-KJ3xq-1767934183524','Lot2'),
  ('2026-01-12','B75807','7',  'LB1','Lot3','รองเท้า',2,'SMBB-KJ3xq-1768200526640','Lot3'),
  ('2026-01-12','CW2288-001','7.5','LB1','Lot3','รองเท้า',27,'SMBB-KJ3xq-1768200526640','Lot3')
ON CONFLICT DO NOTHING;

-- ── SEED: Returns ─────────────────────────────────────────
INSERT INTO returns (date_return, supplier, lot_no, sku, size, quantity, cause) VALUES
  ('2026-02-09','LB1','Lotหลังบ้าน','Dc0774-101','6.5',2,'โดนน้ำ'),
  ('2026-02-09','LB1','Lotหลังบ้าน','Dc0774-101','6.5',2,'โดนน้ำ')
ON CONFLICT DO NOTHING;

-- ── RLS (Row Level Security) — เปิดให้ทุกคนในทีมเข้าถึง ──
-- ถ้าต้องการ Auth ค่อย enable ทีหลัง
ALTER TABLE inventory  ENABLE ROW LEVEL SECURITY;
ALTER TABLE inbound    ENABLE ROW LEVEL SECURITY;
ALTER TABLE outbound   ENABLE ROW LEVEL SECURITY;
ALTER TABLE returns    ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers  ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers  ENABLE ROW LEVEL SECURITY;

-- Allow all for now (ไม่ต้อง login)
CREATE POLICY "allow_all_inventory"  ON inventory  FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_inbound"    ON inbound    FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_outbound"   ON outbound   FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_returns"    ON returns    FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_customers"  ON customers  FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_suppliers"  ON suppliers  FOR ALL USING (true) WITH CHECK (true);

-- ── UPDATED_AT trigger ────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_inventory_updated
  BEFORE UPDATE ON inventory
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ── VIEWS — Dashboard Stats ───────────────────────────────
CREATE OR REPLACE VIEW dashboard_stats AS
SELECT
  (SELECT COUNT(*)       FROM inventory)                           AS total_sku_lines,
  (SELECT COALESCE(SUM(quantity),0) FROM inventory)                AS total_stock,
  (SELECT COUNT(*)       FROM inventory WHERE status='พร้อมขาย')  AS ready_count,
  (SELECT COALESCE(SUM(quantity),0) FROM inventory WHERE status='พร้อมขาย') AS ready_stock,
  (SELECT COUNT(*)       FROM returns)                             AS return_count,
  (SELECT COALESCE(SUM(quantity),0) FROM outbound)                 AS total_outbound,
  (SELECT COUNT(DISTINCT order_id) FROM outbound WHERE order_id IS NOT NULL) AS total_orders;

CREATE OR REPLACE VIEW stock_by_category AS
SELECT category, SUM(quantity) AS total_qty
FROM inventory GROUP BY category ORDER BY total_qty DESC;

CREATE OR REPLACE VIEW stock_by_supplier AS
SELECT supplier, SUM(quantity) AS total_qty
FROM inventory GROUP BY supplier ORDER BY total_qty DESC;
